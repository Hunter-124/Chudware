"""Disposable native Windows benchmark of actual control-server implementations."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import tempfile
import time

parser = argparse.ArgumentParser()
parser.add_argument('--before', action='store_true')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
if os.name != 'nt':
    raise SystemExit('Native Windows required')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'repo'))
if args.before:
    for name, relative in [('services.ipc.windows_pipe', 'services/ipc/windows_pipe.py'),
                           ('services.agent.chudcode_control', 'services/agent/chudcode_control.py')]:
        spec = importlib.util.spec_from_file_location(name, root / 'before' / relative)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
from services.agent.chudcode_control import ControlServer
from services.ipc.windows_pipe import WindowsPipe

with tempfile.TemporaryDirectory(prefix='cw-pipe-benchmark-') as temporary:
    start = time.perf_counter_ns()
    server = ControlServer(lambda action, params: {'state': 'idle'}, temporary).start()
    startup_ms = (time.perf_counter_ns() - start) / 1e6
    try:
        info = server.info()
        start = time.perf_counter_ns()
        cpu = time.process_time_ns()
        time.sleep(8)
        idle_cpu_ms = (time.process_time_ns() - cpu) / 1e6
        idle_wall_ms = (time.perf_counter_ns() - start) / 1e6
        durations = []
        for _ in range(24):
            start = time.perf_counter_ns()
            client = WindowsPipe.connect(info['endpoint'], timeout=5)
            try:
                client.settimeout(5)
                client.sendall(json.dumps({'token': info['token'], 'action': 'status', 'params': {}}).encode() + b'\n')
                response = bytearray()
                while not response.endswith(b'\n'):
                    piece = client.recv(4096)
                    if not piece:
                        raise RuntimeError('control response ended before its newline')
                    response.extend(piece)
                if json.loads(response) != {'ok': True, 'result': {'state': 'idle'}}:
                    raise RuntimeError('wrong control response')
            finally:
                client.close()
            durations.append((time.perf_counter_ns() - start) / 1e6)
    finally:
        stop = time.perf_counter_ns()
        server.stop()
        shutdown_ms = (time.perf_counter_ns() - stop) / 1e6
report = {'implementation': 'before' if args.before else 'after',
          'platform': sys.getwindowsversion()._asdict() if hasattr(sys.getwindowsversion(), '_asdict') else list(sys.getwindowsversion()),
          'python': sys.version, 'startup_ms': startup_ms,
          'idle_wall_ms': idle_wall_ms, 'idle_cpu_ms': idle_cpu_ms,
          'requests': len(durations), 'latency_ms': durations,
          'median_ms': statistics.median(durations),
          'p95_ms': sorted(durations)[(len(durations) * 95 + 99) // 100 - 1],
          'maximum_ms': max(durations), 'shutdown_ms': shutdown_ms,
          'limits': 'Same owned Windows KVM guest; CPU control path only, not GPU or production provider performance.'}
args.output.write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report))
