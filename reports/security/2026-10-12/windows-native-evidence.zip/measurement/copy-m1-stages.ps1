$ErrorActionPreference = 'Stop'
$source = 'C:\cw\gui-m1-日本-é\scratch\m1_shots'
foreach ($stage in @('m1_02_box','m1_05_edit','m1_06_reopen')) {
    Copy-Item -LiteralPath (Join-Path $source ($stage + '.png')) -Destination ('C:\cw\evidence\native-gui-before-' + $stage + '.png')
}
