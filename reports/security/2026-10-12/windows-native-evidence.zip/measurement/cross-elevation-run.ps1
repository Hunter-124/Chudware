$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$name = 'cw-owned-cache-reopen-' + [Guid]::NewGuid().ToString('N')
$destination = 'C:\cw\evidence\cross-elevation.json'
if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination }
$principal = New-ScheduledTaskPrincipal -UserId $sid -LogonType Interactive -RunLevel Limited
$action = New-ScheduledTaskAction -Execute $env:ComSpec -Argument '/d /s /c "C:\cw\run.cmd python C:\cw\cross-elevation-smoke.py >C:\cw\evidence\cross-elevation-run.log 2>&1"'
try {
    Register-ScheduledTask -TaskName $name -Action $action -Principal $principal | Out-Null
    Start-ScheduledTask -TaskName $name
    $deadline = [DateTime]::UtcNow.AddSeconds(120)
    do {
        Start-Sleep -Milliseconds 100
        $task = Get-ScheduledTask -TaskName $name
        $info = Get-ScheduledTaskInfo -TaskName $name
    } while ((-not (Test-Path -LiteralPath $destination) -or $task.State -eq 'Running') -and [DateTime]::UtcNow -lt $deadline)
    if ($task.State -eq 'Running' -or $info.LastTaskResult -ne 0) {
        Get-Content -LiteralPath 'C:\cw\evidence\cross-elevation-run.log'
        throw ('Limited-token native cache reopen failed: ' + $info.LastTaskResult)
    }
    Get-Content -LiteralPath $destination -Raw
} finally {
    Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue
}
