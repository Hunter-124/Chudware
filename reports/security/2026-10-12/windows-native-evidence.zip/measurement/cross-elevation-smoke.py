"""Reopen the owned elevated smoke's saved part with the same user's limited token."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid
root = Path(r'C:\cw')
repo = root / 'repo'
output = root / 'evidence'
state = output / 'runtime-state-after'
binaries = repo / 'build/windows-occt/bin'
sys.path.insert(0, str(repo))
os.environ.update(CHUDWARE_HOSTD_BIN=str(binaries / 'chudware-hostd.exe'),
                  CHUDWARE_LIBCHUDWARE=str(binaries / 'libchudware.dll'),
                  CHUDWARE_PYTHON=str(root / 'python/python.exe'), CHUDWARE_REPO=str(repo),
                  CHUDWARE_INSTANCE_KEY=uuid.uuid4().hex[:12],
                  LOCALAPPDATA=str(state / 'local'), APPDATA=str(state / 'roaming'),
                  CHUDWARE_HOSTD_STALECHECK_S='0', CHUDWARE_HOSTD_LINGER_SECS='300',
                  CHUDWARE_AUTOSAVE_INTERVAL_S='0', CHUDWARE_HOSTD_TRAY='0')
os.environ.pop('CHUDWARE_HOSTD_CONNECT_BUDGET_S', None)
from services.mcp import daemon_bridge
identity = json.loads(subprocess.check_output([str(output / 'private-owner-after.exe')]))
assert identity['elevated'] is False, identity
firmware = json.loads(subprocess.check_output([str(output / 'firmware-after.exe')]))
assert firmware['elevated'] is False and firmware['private_directory'] is True, firmware
client = daemon_bridge.DaemonClient()
process = None
original_spawn = daemon_bridge._spawn_hostd_detached
def owned_spawn(hostd):
    global process
    process = original_spawn(hostd)
    return process
daemon_bridge._spawn_hostd_detached = owned_spawn
try:
    client.connect()
    assert process is not None and process.poll() is None, 'Owned limited-token daemon did not start'
    report = {'elevated': False, 'firmware_private_storage': firmware, 'cases': []}
    for filename in ('native-cache-日本-é.step+', 'native-cold-日本-é.step+'):
        began = time.perf_counter()
        opened = client.call('doc_open', {'path': str(output / filename)})
        case = {'filename': filename, 'reopen_ms': (time.perf_counter() - began) * 1000,
                'warm': opened.get('warm'), 'cache_hit': opened.get('cache_hit'),
                'cache': opened.get('cache'), 'cache_trust': opened.get('cache_trust'),
                'verification_pending': opened.get('cache_verification_pending')}
        assert opened.get('warm') and opened.get('cache_hit'), case
        assert case['cache_trust'] == 'verified' and case['verification_pending'] is False, case
        assert opened['cache']['hydrated_from'] == 'cache.ckpt', case
        activated = client.call('doc_activate', {'doc_id': opened['doc_id']})
        status = activated['rebuild']['doc_status']
        assert status['features_executed'] == 0 and status['features_reused'] == 3, status
        case['activation_status'] = status
        report['cases'].append(case)
        client.call('doc_close', {'doc_id': opened['doc_id']})
    client.close()
    subprocess.run([os.environ['CHUDWARE_HOSTD_BIN'], '--stop'], check=True,
                   capture_output=True, timeout=35)
    process.wait(timeout=35)
    report['clean_shutdown'] = True
    (output / 'cross-elevation.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
finally:
    daemon_bridge._spawn_hostd_detached = original_spawn
    client.close()
    if process is not None and process.poll() is None:
        process.terminate()
        process.wait(timeout=15)
