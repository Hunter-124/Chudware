#include "firmware/private_storage.h"
#include <nlohmann/json.hpp>
#include <iostream>
int main() {
    const auto path = std::filesystem::temp_directory_path() /
        (L"firmware-private-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64()));
    nlohmann::json result;
    HANDLE token = nullptr;
    TOKEN_ELEVATION elevation{};
    DWORD size = 0;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return 2;
    const bool identity = GetTokenInformation(token, TokenElevation, &elevation, sizeof elevation, &size);
    CloseHandle(token);
    if (!identity) return 2;
    result["elevated"] = elevation.TokenIsElevated != 0;
    try {
        const auto created = chudware::firmware::private_directory(path);
        result["private_directory"] = std::filesystem::is_directory(created);
    } catch (const std::exception& error) {
        result["private_directory"] = false;
        result["error"] = error.what();
    }
    std::error_code ignored;
    std::filesystem::remove_all(path, ignored);
    std::cout << result.dump() << '\n';
    return result["private_directory"].get<bool>() ? 0 : 1;
}
