#define NOMINMAX
#include <windows.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <nlohmann/json.hpp>
int main() {
    nlohmann::json report;
    auto failure = [&] {
        const char* detail = nullptr;
        const int code = glfwGetError(&detail);
        return nlohmann::json{{"code", code}, {"message", detail ? detail : ""}};
    };
    report["initialized"] = glfwInit() == GLFW_TRUE;
    if (!report["initialized"].get<bool>()) report["initialization_error"] = failure();
    else {
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        GLFWwindow* window = glfwCreateWindow(32, 32, "owned capability probe", nullptr, nullptr);
        report["opengl33"] = window != nullptr;
        if (!window) {
            report["opengl33_error"] = failure();
            glfwDefaultWindowHints();
            glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
            window = glfwCreateWindow(32, 32, "owned legacy diagnostic", nullptr, nullptr);
        }
        if (window) {
            glfwMakeContextCurrent(window);
            report["version"] = reinterpret_cast<const char*>(glGetString(GL_VERSION));
            report["renderer"] = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
            report["vendor"] = reinterpret_cast<const char*>(glGetString(GL_VENDOR));
            glfwDestroyWindow(window);
        } else report["legacy_error"] = failure();
        glfwTerminate();
    }
    std::cout << report.dump(2, ' ', true) << '\n';
}
