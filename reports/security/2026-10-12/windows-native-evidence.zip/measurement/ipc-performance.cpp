#include "ipc_transport.h"
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <exception>
#include <string>
#include <thread>
#include <vector>
using Clock = std::chrono::steady_clock;
static double cpuMs() {
    FILETIME created{}, exited{}, kernel{}, user{};
    if (!GetProcessTimes(GetCurrentProcess(), &created, &exited, &kernel, &user)) std::terminate();
    ULARGE_INTEGER k{}, u{};
    k.LowPart = kernel.dwLowDateTime; k.HighPart = kernel.dwHighDateTime;
    u.LowPart = user.dwLowDateTime; u.HighPart = user.dwHighDateTime;
    return (k.QuadPart + u.QuadPart) / 10000.0;
}
int main() {
    using namespace chudware_ipc;
    IpcListener listener;
    std::string error;
    const std::string endpoint = "\\\\.\\pipe\\cw-owned-performance-" + std::to_string(GetCurrentProcessId());
    if (!listener.listen(endpoint, error)) { std::fprintf(stderr, "%s\n", error.c_str()); return 2; }
    IpcConn client = connectTo(endpoint, error);
    IpcConn server = listener.accept(2000);
    if (!client.valid() || !server.valid()) return 3;
    HANDLE ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    bool exchanged = true;
    std::thread responder([&] {
        SetEvent(ready);
        for (int i = 0; i < 100; ++i) {
            std::string message;
            if (!server.readLine(message, -1) || message != "ping" || !server.writeLine("pong")) {
                exchanged = false;
                return;
            }
        }
    });
    WaitForSingleObject(ready, 2000);
    const double cpu = cpuMs();
    Sleep(8000);
    const double idleCpu = cpuMs() - cpu;
    std::vector<double> latencies;
    for (int i = 0; i < 100; ++i) {
        const auto began = Clock::now();
        std::string message;
        if (!client.writeLine("ping") || !client.readLine(message, 2000) || message != "pong") std::terminate();
        latencies.push_back(std::chrono::duration<double, std::milli>(Clock::now() - began).count());
    }
    responder.join();
    ResetEvent(ready);
    HANDLE completed = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    std::thread blocked([&] {
        std::string message;
        SetEvent(ready);
        server.readLine(message, -1);
        SetEvent(completed);
    });
    WaitForSingleObject(ready, 2000);
    Sleep(50);
    const auto began = Clock::now();
    server.shutdown();
    const bool woke = WaitForSingleObject(completed, 500) == WAIT_OBJECT_0;
    const double shutdown = std::chrono::duration<double, std::milli>(Clock::now() - began).count();
    client.close();
    if (WaitForSingleObject(completed, 2000) != WAIT_OBJECT_0) std::terminate();
    blocked.join();
    CloseHandle(completed);
    CloseHandle(ready);
    std::sort(latencies.begin(), latencies.end());
    std::printf("{\"idle_wall_ms\":8000,\"idle_cpu_ms\":%.6f,\"round_trips\":100,\"median_ms\":%.6f,\"p95_ms\":%.6f,\"maximum_ms\":%.6f,\"shutdown_woke\":%s,\"shutdown_wait_ms\":%.6f,\"responses_correct\":%s}\n",
        idleCpu, (latencies[49] + latencies[50]) / 2, latencies[94], latencies[99], woke ? "true" : "false", shutdown, exchanged ? "true" : "false");
    return exchanged && woke ? 0 : 1;
}
