#include "cpp_core.h"
#include <cstdlib>
#include <iostream>
int main() {
    const std::string path = u8"C:\\cw\\evidence\\\u65e5\u672c-\u00e9-missing\\libchudware.dll";
    _putenv_s("CHUDWARE_LIBCHUDWARE", path.c_str());
    core::CppCore engine;
    std::string error;
    const bool loaded = engine.ensureLoaded(error);
    const bool preserved = error.find(path) != std::string::npos;
    std::cout << nlohmann::json{{"loaded", loaded}, {"requested_path_preserved", preserved}}.dump() << '\n';
    return !loaded && preserved ? 0 : 1;
}
