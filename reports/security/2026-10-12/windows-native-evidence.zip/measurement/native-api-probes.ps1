$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& C:\cw\run.cmd cl /nologo /std:c++17 /utf-8 /MD /O2 /EHsc /I C:\cw\deps\json\include C:\cw\rename-contract.cpp /Fo:C:\cw\rename-contract.obj /Fe:C:\cw\rename-contract.exe
if ($LASTEXITCODE -ne 0) { throw 'Native rename probe compilation failed' }
& C:\cw\rename-contract.exe | Tee-Object -FilePath 'C:\cw\evidence\rename-contract.json'
if ($LASTEXITCODE -ne 0) { throw 'Native rename probe failed' }
$glfw = @(Get-ChildItem -LiteralPath 'C:\cw\repo\host\build-win' -Filter glfw3.lib -Recurse -File)
if ($glfw.Count -ne 1) { throw 'Expected one built native GLFW library' }
& C:\cw\run.cmd cl /nologo /std:c++17 /utf-8 /MD /O2 /EHsc /I C:\cw\deps\json\include /I C:\cw\deps\glfw\include C:\cw\glfw-capability.cpp $glfw[0].FullName user32.lib gdi32.lib shell32.lib opengl32.lib /Fo:C:\cw\glfw-capability.obj /Fe:C:\cw\glfw-capability.exe /link /LTCG
if ($LASTEXITCODE -ne 0) { throw 'Native graphics capability probe compilation failed' }
& C:\cw\glfw-capability.exe | Tee-Object -FilePath 'C:\cw\evidence\glfw-capability.json'
if ($LASTEXITCODE -ne 0) { throw 'Native graphics capability probe failed' }
