$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
Set-Location -LiteralPath 'C:\cw\repo'
$source = @()
foreach ($name in @('eigen','json','miniz','spectra','doctest','clipper2','glfw','stb','imgui')) {
    $source += ('-DFETCHCONTENT_SOURCE_DIR_' + $name.ToUpperInvariant() + '=C:/cw/deps/' + $name)
}
$native = @('-DPOLYMESH_SOURCE_DIR=C:/cw/deps/polymesh', '-DOPENNURBS_LOCAL_SOURCE_DIR=C:/cw/deps/opennurbs', '-DFETCHCONTENT_SOURCE_DIR_ONNXRUNTIME=C:/cw/deps/onnxruntime-win-x64-1.28.0')
& $env:ComSpec /d /s /c ('C:\cw\run.cmd cmake --preset windows-occt ' + ($source -join ' ') + ' ' + ($native -join ' ') + ' 2>&1') | Tee-Object -FilePath 'C:\cw\evidence\core-configure.log'
if ($LASTEXITCODE -ne 0) { throw 'Native core configure failed' }
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cmake --build --preset windows-occt --parallel 3 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\core-build.log'
if ($LASTEXITCODE -ne 0) { throw 'Native core build failed' }
& $env:ComSpec /d /s /c ('C:\cw\run.cmd cmake -S host -B host/build-win -G Ninja -DCMAKE_BUILD_TYPE=Release -DCHUDWARE_LTO=ON -DCHUDWARE_ENABLE_CEF=OFF ' + ($source -join ' ') + ' 2>&1') | Tee-Object -FilePath 'C:\cw\evidence\host-configure.log'
if ($LASTEXITCODE -ne 0) { throw 'Native host configure failed' }
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cmake --build host/build-win --parallel 3 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\host-build.log'
if ($LASTEXITCODE -ne 0) { throw 'Native host build failed' }
& $env:ComSpec /d /s /c 'C:\cw\run.cmd ctest --test-dir build/windows-occt/core --output-on-failure --no-tests=error --output-junit C:/cw/evidence/core-ctest.xml 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\core-ctest.log'
$coreStatus = $LASTEXITCODE
& $env:ComSpec /d /s /c 'C:\cw\run.cmd ctest --test-dir host/build-win --output-on-failure --no-tests=error --output-junit C:/cw/evidence/host-ctest.xml 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\host-ctest.log'
$hostStatus = $LASTEXITCODE
if ($coreStatus -ne 0 -or $hostStatus -ne 0) {
    throw "Native integrated CTest failed: core=$coreStatus, host=$hostStatus"
}
