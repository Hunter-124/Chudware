"""Compare real Windows console creation without relaxing process classification."""
import ctypes
from ctypes import wintypes as w
import json
import os
from pathlib import Path
import subprocess
import sys
import time
sys.path.insert(0, r'C:\cw\repo')
if '--child' in sys.argv:
    from services import worker_activity, windows_process
    kernel = windows_process._kernel()
    kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
    kernel.QueryFullProcessImageNameW.restype = w.BOOL
    records = []
    for pid, (parent, created) in windows_process.process_tree(os.getpid(), 65536).items():
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            size = w.DWORD(32768)
            image = ctypes.create_unicode_buffer(size.value)
            if not kernel.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(size)):
                raise ctypes.WinError(ctypes.get_last_error())
            records.append({'pid': pid, 'parent': parent, 'image': image.value, 'created': created})
        finally:
            kernel.CloseHandle(handle)
    print(json.dumps({'processes': records, 'activity': worker_activity.snapshot()}))
else:
    report = {}
    for name, flags in (('CREATE_NO_WINDOW', subprocess.CREATE_NO_WINDOW), ('DETACHED_PROCESS', subprocess.DETACHED_PROCESS)):
        began = time.perf_counter()
        child = subprocess.run([sys.executable, __file__, '--child'], stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags, timeout=30)
        if child.returncode:
            raise RuntimeError(child.stderr.decode(errors='replace'))
        report[name] = json.loads(child.stdout)
        report[name]['elapsed_ms'] = (time.perf_counter() - began) * 1000
    Path(r'C:\cw\evidence\native-console-probe.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
