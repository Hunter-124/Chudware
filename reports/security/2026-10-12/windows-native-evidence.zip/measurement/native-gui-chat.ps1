$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$root = 'C:\cw\gui-noengine'
New-Item -ItemType Directory -Path $root -Force | Out-Null
Copy-Item -LiteralPath 'C:\cw\repo\host\build-win\bin' -Destination $root -Recurse -Force
$env:CHUDWARE_WORKER_BIN = $root + '\missing-worker.exe'
$env:CHUDWARE_LIBCHUDWARE = $root + '\missing-engine.dll'
$env:CHUDWARE_ENGINE_DAEMON = '0'
$env:CHUDWARE_HIDDEN = '1'
$env:CHUDWARE_SHOT = 'chat'
$env:CHUDWARE_HOSTD_TRAY = '0'
Remove-Item Env:CHUDWARE_REPO -ErrorAction SilentlyContinue
$shot = 'C:\cw\evidence\native-gui-chat.png'
$p = Start-Process -FilePath ($root + '\bin\chudware.exe') -ArgumentList @('--ui-screenshot',$shot) -WorkingDirectory $root -RedirectStandardOutput 'C:\cw\evidence\native-gui-chat.stdout.log' -RedirectStandardError 'C:\cw\evidence\native-gui-chat.stderr.log' -PassThru
if (!$p.WaitForExit(90000)) { $p.Kill(); $p.WaitForExit(); throw 'Owned native GUI smoke exceeded its scenario deadline' }
$result = [ordered]@{exit_code=$p.ExitCode; screenshot_present=(Test-Path -LiteralPath $shot); scope='Owned native Windows guest, copied SDK-less desktop, no engine or provider, no GPU acceleration claim'}
$result | ConvertTo-Json | Set-Content -LiteralPath 'C:\cw\evidence\native-gui-chat-result.json' -Encoding UTF8
$result | ConvertTo-Json
Get-Content -LiteralPath 'C:\cw\evidence\native-gui-chat.stderr.log'
if ($p.ExitCode -ne 0 -or -not $result.screenshot_present) { throw 'Native desktop surface smoke did not produce a capture' }
