$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cmake --build host/build-win --parallel 3 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\native-gui-final-build.log'
if ($LASTEXITCODE -ne 0) { throw 'Native GUI integration build failed' }
Copy-Item -LiteralPath 'C:\cw\repo\host\build-win\bin\chudware.exe' -Destination 'C:\cw\gui-noengine\bin\chudware.exe' -Force
& 'C:\cw\python\python.exe' 'C:\cw\native-gui-surface.py'
if ($LASTEXITCODE -ne 0) { throw 'Native cached viewport and canonical-path smoke failed' }

& $env:ComSpec /d /s /c 'C:\cw\run.cmd ctest --test-dir host/build-win --output-on-failure --no-tests=error --output-junit C:/cw/evidence/host-ctest-final.xml 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\host-ctest-final.log'
if ($LASTEXITCODE -ne 0) { throw 'Final native host CTest failed' }