import ctypes
import json
import os
from pathlib import Path
import subprocess

root = Path(r'C:\cw\gui-noengine')
output = Path(r'C:\cw\evidence')
report = {'scope': 'Owned native Windows desktop diagnostics; no engine, provider or GPU qualification'}
dependencies = {}
for name in ('MSVCP140.dll', 'MSVCP140_2.dll', 'VCRUNTIME140_1.dll', 'MFPlat.dll', 'MF.dll', 'MFReadWrite.dll', 'opengl32.dll'):
    try:
        ctypes.WinDLL(name)
        dependencies[name] = {'loaded': True}
    except OSError as error:
        dependencies[name] = {'loaded': False, 'winerror': error.winerror, 'message': str(error)}
report['dependencies'] = dependencies
environment = dict(os.environ, CHUDWARE_WORKER_BIN=str(root / 'missing-worker.exe'),
                   CHUDWARE_LIBCHUDWARE=str(root / 'missing-engine.dll'), CHUDWARE_ENGINE_DAEMON='0',
                   CHUDWARE_HIDDEN='1', CHUDWARE_SHOT='chat', CHUDWARE_HOSTD_TRAY='0',
                   CHUDWARE_STARTUP_TRACE='1', CHUDWARE_LOG_FILE=str(output / 'native-gui-trace.log'))
environment.pop('CHUDWARE_REPO', None)
with (output / 'native-gui-probe.stdout.log').open('wb') as stdout, (output / 'native-gui-probe.stderr.log').open('wb') as stderr:
    result = subprocess.run([str(root / 'bin/chudware.exe'), '--ui-screenshot', str(output / 'native-gui-chat.png')],
                            cwd=root, env=environment, stdout=stdout, stderr=stderr, timeout=90)
report['exit_code'] = result.returncode
report['exit_hex'] = hex(result.returncode & 0xffffffff)
report['screenshot_present'] = (output / 'native-gui-chat.png').is_file()
(output / 'native-gui-probe.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
print((output / 'native-gui-probe.stderr.log').read_text(encoding='utf-8', errors='replace'))
