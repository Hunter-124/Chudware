"""Exercise the real native desktop with diagnostic-only per-app software OpenGL."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import zipfile
root = Path(r'C:\cw')
output = root / 'evidence'
application = root / 'gui-noengine/bin/chudware.exe'
engine = root / 'repo/build/windows-occt/bin/libchudware.dll'
workspace = root / 'gui-m1-日本-é'
workspace.mkdir(exist_ok=True)
profile = root / 'gui-profile'
for child in ('local', 'roaming'):
    (profile / child).mkdir(parents=True, exist_ok=True)
environment = dict(os.environ, GALLIUM_DRIVER='llvmpipe', CHUDWARE_ENGINE_DAEMON='0',
    CHUDWARE_WORKER_BIN=str(root / 'missing-worker.exe'), CHUDWARE_HIDDEN='1',
    CHUDWARE_HOSTD_TRAY='0', CHUDWARE_STARTUP_TRACE='1',
    LOCALAPPDATA=str(profile / 'local'), APPDATA=str(profile / 'roaming'))
environment.pop('CHUDWARE_REPO', None)
report = {'scope': 'Actual native Windows Release/LTO CEF-off desktop; diagnostic per-app llvmpipe, not GPU or installed-runtime qualification',
          'application_sha256': hashlib.file_digest(application.open('rb'), 'sha256').hexdigest(),
          'engine_sha256': hashlib.file_digest(engine.open('rb'), 'sha256').hexdigest(),
          'cases': []}
try:
    for name, scenario, available, expected in (
        ('m1', 'm1', True, 0), ('m1-noengine', 'm1', False, 1), ('chat-noengine', 'chat', False, 0)):
        shot = output / ('native-gui-' + name + '.png')
        shot.unlink(missing_ok=True)
        environment.update(CHUDWARE_SHOT=scenario,
            CHUDWARE_LIBCHUDWARE=str(engine if available else root / 'missing-engine.dll'))
        began = time.perf_counter()
        with (output / ('native-gui-' + name + '.stdout.log')).open('wb') as stdout, (output / ('native-gui-' + name + '.stderr.log')).open('wb') as stderr:
            result = subprocess.run([str(application), '--ui-screenshot', str(shot)], cwd=workspace,
                                    env=environment, stdout=stdout, stderr=stderr, timeout=180)
        entry = {'name': name, 'exit_code': result.returncode,
                 'elapsed_ms': (time.perf_counter() - began) * 1000, 'screenshot': shot.is_file()}
        report['cases'].append(entry)
        assert result.returncode == expected, entry
        if expected == 0:
            assert shot.read_bytes()[:8] == b'\x89PNG\r\n\x1a\n', entry
            entry['screenshot_bytes'] = shot.stat().st_size
        else:
            assert not shot.exists(), entry
        if name == 'm1':
            saved = workspace / 'scratch/m1_shots/part.step+'
            with zipfile.ZipFile(saved) as archive:
                assert {'document.json', 'cache.ckpt', 'cache.provenance'} <= set(archive.namelist()), archive.namelist()
            entry['saved_archive_bytes'] = saved.stat().st_size
    report['passed'] = True
finally:
    (output / 'native-gui-surface.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
