$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& 'C:\cw\python\python.exe' 'C:\cw\native-gui-surface.py'
if ($LASTEXITCODE -ne 0) { throw 'Native desktop surface smoke failed' }
