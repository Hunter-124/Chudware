$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$trees = @(
    @{name='core'; root='C:\cw\repo\build\windows-occt'; headers=@('miniz_export.h','firmware_bus_sources.h'); configure='cmake --preset windows-occt'; build='cmake --build --preset windows-occt --parallel 3'},
    @{name='host'; root='C:\cw\repo\host\build-win'; headers=@('miniz_export.h'); configure='cmake -S host -B host/build-win'; build='cmake --build host/build-win --parallel 3'}
)
$results = @()
foreach ($tree in $trees) {
    $name = $tree.name
    $snapshots = @()
    foreach ($pattern in $tree.headers) {
        $headers = @(Get-ChildItem -LiteralPath $tree.root -Filter $pattern -Recurse -File)
        if ($headers.Count -ne 1) { throw "Expected one generated header: $name/$pattern" }
        $path = $headers[0].FullName
        $snapshots += [ordered]@{tree=$name; header=$path; timestamp_before=(Get-Item -LiteralPath $path).LastWriteTimeUtc.ToString('o'); sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
    }
    & $env:ComSpec /d /s /c ("C:\cw\run.cmd " + $tree.configure + ' 2>&1') | Tee-Object -FilePath "C:\cw\evidence\incremental-$name-configure.log"
    if ($LASTEXITCODE -ne 0) { throw "Native incremental configure failed: $name" }
    foreach ($result in $snapshots) {
        $result.timestamp_after = (Get-Item -LiteralPath $result.header).LastWriteTimeUtc.ToString('o')
        $result.timestamp_preserved = $result.timestamp_before -eq $result.timestamp_after
        $result.content_preserved = $result.sha256 -eq (Get-FileHash -LiteralPath $result.header -Algorithm SHA256).Hash
        if (-not $result.timestamp_preserved -or -not $result.content_preserved) { throw "Unchanged configure invalidated the dependency header: $($result.header)" }
        $results += $result
    }
    & $env:ComSpec /d /s /c ("C:\cw\run.cmd " + $tree.build + ' 2>&1') | Tee-Object -FilePath "C:\cw\evidence\incremental-$name-build.log"
    if ($LASTEXITCODE -ne 0) { throw "Native incremental build failed: $name" }
    if (Select-String -LiteralPath "C:\cw\evidence\incremental-$name-build.log" -Pattern '^\[\d+/\d+\] (Building|Linking) ' -Quiet) { throw "Unchanged configure compiled or linked native code: $name" }
}
$results | ConvertTo-Json | Set-Content -LiteralPath C:\cw\evidence\incremental-headers.json -Encoding UTF8
$results | ConvertTo-Json
