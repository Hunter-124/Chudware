#include <filesystem>
#include <iostream>
#include <nlohmann/json.hpp>
int main() {
    namespace fs = std::filesystem;
    const std::string relative = "./scratch/m1_shots/part.step+";
    const std::string absolute = u8"C:/cw/gui-m1-日本-é/scratch/m1_shots/part.step+";
    nlohmann::json report;
    auto check = [&](const char* name, bool utf8, const std::string& input) {
        try {
            std::error_code ec;
            const auto path = utf8 ? fs::u8path(input) : fs::path(input);
            const auto canonical = fs::weakly_canonical(path, ec);
            const std::string normalized = utf8 ? canonical.generic_u8string() : canonical.string();
            report[name] = {{"exists", fs::exists(path)}, {"normalized", normalized},
                            {"canonical_error", ec.message()}};
        } catch (const std::exception& error) {
            report[name] = {{"error", error.what()}};
        }
    };
    check("legacy_relative", false, relative);
    check("utf8_relative", true, relative);
    check("legacy_absolute", false, absolute);
    check("utf8_absolute", true, absolute);
    std::cout << report.dump(2, ' ', true) << '\n';
    return report["utf8_relative"].value("exists", false) &&
           report["utf8_absolute"].value("exists", false) ? 0 : 1;
}
