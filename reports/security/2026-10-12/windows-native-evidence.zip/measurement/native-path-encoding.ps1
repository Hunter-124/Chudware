$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cl /nologo /EHsc /std:c++17 /utf-8 /O2 /MD /I C:\cw\deps\json\single_include C:\cw\native-path-encoding.cpp /FoC:\cw\native-path-encoding.obj /FeC:\cw\native-path-encoding.exe'
if ($LASTEXITCODE -ne 0) { throw 'Native path probe build failed' }
Push-Location -LiteralPath 'C:\cw\gui-m1-日本-é'
try {
    & 'C:\cw\native-path-encoding.exe' | Tee-Object -FilePath 'C:\cw\evidence\native-path-encoding.json'
    if ($LASTEXITCODE -ne 0) { throw 'Native UTF-8 path probe failed' }
} finally { Pop-Location }
