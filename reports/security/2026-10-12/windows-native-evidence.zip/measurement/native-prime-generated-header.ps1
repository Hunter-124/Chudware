$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cmake --preset windows-occt 2>&1' | Tee-Object -FilePath C:\cw\evidence\generated-header-configure.log
if ($LASTEXITCODE -ne 0) { throw 'Corrected generated-header configure failed' }
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cmake --build --preset windows-occt --parallel 3 2>&1' | Tee-Object -FilePath C:\cw\evidence\generated-header-build.log
if ($LASTEXITCODE -ne 0) { throw 'Corrected generated-header build failed' }
