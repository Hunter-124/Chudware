$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$files = @(Get-Item -LiteralPath 'C:\cw\repo\core\doc\stepplus.cpp')
foreach ($name in @('stepplus.cpp.obj','chudware_doc.lib','test_sim_cache.exe','libchudware.dll')) {
    $files += @(Get-ChildItem -LiteralPath 'C:\cw\repo\build\windows-occt' -Filter $name -File -Recurse)
}
$results = @($files | ForEach-Object { [ordered]@{path=$_.FullName; modified=$_.LastWriteTimeUtc.ToString('o'); bytes=$_.Length; sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash} })
$results | ConvertTo-Json | Set-Content -LiteralPath 'C:\cw\evidence\native-archive-build-provenance.json' -Encoding UTF8
$results | ConvertTo-Json
