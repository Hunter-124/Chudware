$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
Set-Location -LiteralPath 'C:\cw\repo'
& 'C:\cw\run.cmd' python -X utf8 -m pytest services/agent/test_chudcode_control.py services/mcp/test_hostd_privacy.py::test_native_ipc_privacy_and_socket_activation services/test_worker_activity.py::test_native_windows_census_tracks_descendants_and_kernel_identity scripts/test_windows_build.py packaging/test_finalize_release.py packaging/test_qualify_native_release.py -q -ra --junitxml=C:\cw\evidence\native-python-complete.xml
if ($LASTEXITCODE -ne 0) { throw 'Native control/census/build/release regressions failed' }
