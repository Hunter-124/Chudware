$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& C:\cw\run.cmd python -X utf8 C:\cw\native-runtime-profiled.py
if ($LASTEXITCODE -ne 0) { throw 'Native daemon/cache/worker smoke failed' }
