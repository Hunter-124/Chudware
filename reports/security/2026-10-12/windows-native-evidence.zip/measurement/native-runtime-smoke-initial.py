"""Disposable native-Windows runtime smoke; no provider calls or publication authority."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import uuid

if os.name != 'nt':
    raise SystemExit('Native Windows required')
root = Path(r'C:\cw')
repo = root / 'repo'
sys.path.insert(0, str(repo))
output = root / 'evidence'
state = output / 'runtime-state-after'
state.mkdir(exist_ok=True)
for profile_directory in ('local', 'roaming'):
    (state / profile_directory).mkdir(exist_ok=True)
bin_dir = repo / 'build/windows-occt/bin'
os.environ.update(CHUDWARE_HOSTD_BIN=str(bin_dir / 'chudware-hostd.exe'),
                  CHUDWARE_LIBCHUDWARE=str(bin_dir / 'libchudware.dll'),
                  CHUDWARE_PYTHON=str(root / 'python/python.exe'),
                  CHUDWARE_REPO=str(repo),
                  CHUDWARE_INSTANCE_KEY=uuid.uuid4().hex[:12],
                  LOCALAPPDATA=str(state / 'local'), APPDATA=str(state / 'roaming'),
                  CHUDWARE_HOSTD_STALECHECK_S='0', CHUDWARE_HOSTD_LINGER_SECS='300',
                  CHUDWARE_AUTOSAVE_INTERVAL_S='0', CHUDWARE_HOSTD_TRAY='0')
from services.mcp.daemon_bridge import DaemonClient, DaemonError

report = {'kind': 'native Windows developer runtime smoke',
          'limits': 'Owned KVM guest; no GPU, provider, installed-runtime or publisher qualification.'}
process = None
client = None
log = (output / 'runtime-smoke.log').open('wb')
def start():
    global process, client
    began = time.perf_counter()
    process = subprocess.Popen([os.environ['CHUDWARE_HOSTD_BIN'], '--foreground'],
                               stdin=subprocess.DEVNULL, stdout=log, stderr=log)
    deadline = time.monotonic() + 30
    last_error = None
    while process.poll() is None and time.monotonic() < deadline:
        client = DaemonClient()
        try:
            client.connect(spawn=False, budget_s=max(.01, deadline - time.monotonic()))
            return (time.perf_counter() - began) * 1000
        except DaemonError as exc:
            last_error = str(exc)
            client.close()
            time.sleep(.05)
    raise RuntimeError(f'Owned native daemon did not become ready (exit={process.poll()}, last_error={last_error}); inspect runtime-smoke.log')
def call(method, params=None):
    result = client.call(method, params or {})
    if isinstance(result, dict) and result.get('_is_error'):
        raise RuntimeError('Native RPC failed: ' + method + ': ' + json.dumps(result))
    return result
def timed(method, params=None):
    began = time.perf_counter()
    result = call(method, params)
    return result, (time.perf_counter() - began) * 1000
def stop():
    global process, client
    if client:
        client.close()
        client = None
    if process and process.poll() is None:
        # Stop only this exact isolated instance, never any existing user daemon.
        stopped = subprocess.run([os.environ['CHUDWARE_HOSTD_BIN'], '--stop'],
                                 capture_output=True, timeout=35)
        if stopped.returncode:
            raise RuntimeError('Owned native daemon refused clean stop')
        process.wait(timeout=35)
    process = None
try:
    report['first_connect_ms'] = start()
    created, report['engine_ready_new_document_ms'] = timed('doc_new', {'kind': 'part', 'name': 'Native saved-state smoke'})
    doc_id = created['doc_id']
    features = [
        {'type': 'box', 'name': 'Base', 'params': {'length': 40, 'width': 24, 'height': 12}},
        {'type': 'box', 'name': 'Second', 'params': {'length': 10, 'width': 10, 'height': 10, 'at': [60, 0, 0], 'mode': 'new'}},
        {'type': 'box', 'name': 'Third', 'params': {'length': 8, 'width': 8, 'height': 8, 'at': [-60, 0, 0], 'mode': 'new'}},
    ]
    built, report['build_three_features_ms'] = timed('doc_apply_ops', {'doc_id': doc_id, 'base_revision': -1,
        'ops': [{'op': 'add_feature', 'feature': feature} for feature in features]})
    report['built_status'] = built['rebuild']['doc_status']
    path = output / 'native-cache-reopen.step+'
    saved, report['save_ms'] = timed('doc_save', {'doc_id': doc_id, 'path': str(path)})
    assert saved['cache']['checkpoints']['written'], saved['cache']
    report['saved_archive_bytes'] = path.stat().st_size
    report['saved_checkpoints'] = saved['cache']['checkpoints']
    last = call('doc_tree', {'doc_id': doc_id})['tree']['features'][-1]['id']
    call('doc_close', {'doc_id': doc_id})
    stop()
    report['restart_connect_ms'] = start()
    opened, report['saved_reopen_ms'] = timed('doc_open', {'path': str(path)})
    assert opened['warm'] and opened['cache_hit'], opened['cache']
    assert opened['cache']['hydrated_from'] == 'cache.ckpt', opened['cache']
    report['opened_cache'] = opened['cache']
    doc_id = opened['doc_id']
    activated, report['activate_ms'] = timed('doc_activate', {'doc_id': doc_id})
    assert activated['rebuild']['doc_status']['features_executed'] == 0
    report['activated_status'] = activated['rebuild']['doc_status']
    edited, report['tail_edit_ms'] = timed('doc_apply_ops', {'doc_id': doc_id, 'base_revision': -1, 'ops': [
        {'op': 'edit_feature', 'id': last, 'params': {'length': {'value': 16, 'expr': None}}}]})
    edit_status = edited['rebuild']['doc_status']
    assert edit_status['features_executed'] == 1 and edit_status['features_reused'] == 2, edit_status
    assert abs(edited['volume'] - (40 * 24 * 12 + 1000 + 16 * 8 * 8)) < 1e-6
    report['tail_edit_status'] = edit_status
    activity, report['first_python_worker_rpc_ms'] = timed('worker_activity')
    report['python_worker_activity'] = activity
    info, report['first_agent_worker_rpc_ms'] = timed('worker_control_info')
    assert info.get('transport') == 'named_pipe', 'Native worker did not expose its real private pipe'
    report['agent_control_transport'] = info['transport']
    info.clear()  # Never retain control credentials in evidence or logs.
    latencies = []
    for _ in range(100):
        _result, duration = timed('ping')
        latencies.append(duration)
    report['ping_round_trip_ms'] = {'count': len(latencies), 'median': statistics.median(latencies),
                                  'p95': sorted(latencies)[94], 'maximum': max(latencies)}
    call('doc_close', {'doc_id': doc_id})
    stop()
    report['clean_shutdown'] = True
    (output / 'native-runtime-smoke.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
finally:
    if client:
        client.close()
    if process and process.poll() is None:
        process.terminate()
        process.wait(timeout=15)
    log.close()
