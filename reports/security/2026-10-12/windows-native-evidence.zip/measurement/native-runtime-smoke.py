"""Disposable native-Windows runtime smoke; no provider calls or publication authority."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import uuid
import zipfile

if os.name != 'nt':
    raise SystemExit('Native Windows required')
root = Path(r'C:\cw')
repo = root / 'repo'
sys.path.insert(0, str(repo))
output = root / 'evidence'
state = output / 'runtime-state-after'
state.mkdir(exist_ok=True)
for profile_directory in ('local', 'roaming'):
    (state / profile_directory).mkdir(exist_ok=True)
bin_dir = repo / 'build/windows-occt/bin'
os.environ.update(CHUDWARE_HOSTD_BIN=str(bin_dir / 'chudware-hostd.exe'),
                  CHUDWARE_LIBCHUDWARE=str(bin_dir / 'libchudware.dll'),
                  CHUDWARE_PYTHON=str(root / 'python/python.exe'),
                  CHUDWARE_REPO=str(repo),
                  CHUDWARE_INSTANCE_KEY=uuid.uuid4().hex[:12],
                  LOCALAPPDATA=str(state / 'local'), APPDATA=str(state / 'roaming'),
                  CHUDWARE_HOSTD_STALECHECK_S='0', CHUDWARE_HOSTD_LINGER_SECS='300',
                  CHUDWARE_AUTOSAVE_INTERVAL_S='0', CHUDWARE_HOSTD_TRAY='0')
os.environ.pop('CHUDWARE_HOSTD_CONNECT_BUDGET_S', None)
from services.mcp import daemon_bridge

report = {'kind': 'native Windows developer runtime smoke',
          'limits': 'Owned KVM guest; no GPU, provider, installed-runtime or publisher qualification.',
          'startup_route': 'Production DaemonClient.connect() automatic spawn and default deadlines; wrapper only times the real spawn function.'}
process = None
client = None
def start():
    global process, client
    began = time.perf_counter()
    span = {}
    original_spawn = daemon_bridge._spawn_hostd_detached
    def measured_spawn(hostd):
        global process
        span['began'] = time.perf_counter()
        process = original_spawn(hostd)
        span['finished'] = time.perf_counter()
        return process
    client = daemon_bridge.DaemonClient()
    daemon_bridge._spawn_hostd_detached = measured_spawn
    try:
        client.connect()
    finally:
        daemon_bridge._spawn_hostd_detached = original_spawn
    ready = time.perf_counter()
    assert span and process is not None and process.poll() is None, 'Owned automatic spawn did not remain live'
    report.setdefault('startup_phases', []).append({
        'pre_spawn_ms': (span['began'] - began) * 1000,
        'process_creation_ms': (span['finished'] - span['began']) * 1000,
        'ready_after_creation_ms': (ready - span['finished']) * 1000,
        'total_ms': (ready - began) * 1000})
    return (ready - began) * 1000
def call(method, params=None):
    result = client.call(method, params or {})
    if isinstance(result, dict) and result.get('_is_error'):
        raise RuntimeError('Native RPC failed: ' + method + ': ' + json.dumps(result))
    return result
def require_trusted_checkpoint(opened):
    assert opened['warm'] and opened['cache_hit'], opened
    assert opened['cache']['hydrated_from'] == 'cache.ckpt', opened['cache']
    assert opened['cache']['features_executed'] == 0, opened['cache']
    assert opened.get('cache_trust') == 'verified', opened
    assert opened.get('cache_verification_pending') is False, opened
def timed(method, params=None):
    began = time.perf_counter()
    result = call(method, params)
    return result, (time.perf_counter() - began) * 1000
def stop():
    global process, client
    if client:
        client.close()
        client = None
    if process and process.poll() is None:
        # Stop only this exact isolated instance, never any existing user daemon.
        stopped = subprocess.run([os.environ['CHUDWARE_HOSTD_BIN'], '--stop'],
                                 capture_output=True, timeout=35)
        if stopped.returncode:
            raise RuntimeError('Owned native daemon refused clean stop')
        process.wait(timeout=35)
    process = None
try:
    report['first_connect_ms'] = start()
    created, report['engine_ready_new_document_ms'] = timed('doc_new', {'kind': 'part', 'name': 'Native saved-state smoke'})
    doc_id = created['doc_id']
    features = [
        {'type': 'box', 'name': 'Base', 'params': {'length': 40, 'width': 24, 'height': 12}},
        {'type': 'box', 'name': 'Second', 'params': {'length': 10, 'width': 10, 'height': 10, 'at': [60, 0, 0], 'mode': 'new'}},
        {'type': 'box', 'name': 'Third', 'params': {'length': 8, 'width': 8, 'height': 8, 'at': [-60, 0, 0], 'mode': 'new'}},
    ]
    built, report['build_three_features_ms'] = timed('doc_apply_ops', {'doc_id': doc_id, 'base_revision': -1,
        'ops': [{'op': 'add_feature', 'feature': feature} for feature in features]})
    report['built_status'] = built['rebuild']['doc_status']
    path = output / 'native-cache-日本-é.step+'
    mixed_path = str(path.parent) + '/' + path.name
    report['saved_filename'] = path.name
    saved, report['save_ms'] = timed('doc_save', {'doc_id': doc_id, 'path': mixed_path})
    assert saved['cache']['checkpoints']['written'], saved['cache']
    overwritten, report['overwrite_ms'] = timed('doc_save', {'doc_id': doc_id, 'path': mixed_path})
    assert overwritten['cache']['checkpoints']['written'], overwritten['cache']
    report['saved_archive_bytes'] = path.stat().st_size
    report['saved_checkpoints'] = saved['cache']['checkpoints']
    derived = {'cache.json', 'cache.aicm', 'cache.brep', 'cache.ckpt', 'cache.provenance', 'geometry.step'}
    with zipfile.ZipFile(path) as archive:
        source_members = {name: archive.read(name) for name in archive.namelist() if name not in derived}
    assert 'document.json' in source_members
    cold_path = output / 'native-cold-日本-é.step+'
    cold_request = str(cold_path.parent) + '/' + cold_path.name
    # Create through the native saver first; truncation below retains its real user ACL/owner.
    call('doc_save', {'doc_id': doc_id, 'path': cold_request})
    report['cache_only_filename'] = cold_path.name
    with zipfile.ZipFile(cold_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in source_members.items():
            archive.writestr(name, data)
    last = call('doc_tree', {'doc_id': doc_id})['tree']['features'][-1]['id']
    call('doc_close', {'doc_id': doc_id})
    stop()
    report['restart_connect_ms'] = start()
    opened, report['saved_reopen_ms'] = timed('doc_open', {'path': str(path)})
    require_trusted_checkpoint(opened)
    report['opened_cache'] = opened['cache']
    report['opened_cache_trust'] = opened['cache_trust']
    report['opened_verification_pending'] = opened['cache_verification_pending']
    doc_id = opened['doc_id']
    activated, report['activate_ms'] = timed('doc_activate', {'doc_id': doc_id})
    assert activated['rebuild']['doc_status']['features_executed'] == 0
    report['activated_status'] = activated['rebuild']['doc_status']
    edited, report['tail_edit_ms'] = timed('doc_apply_ops', {'doc_id': doc_id, 'base_revision': -1, 'ops': [
        {'op': 'edit_feature', 'id': last, 'params': {'length': {'value': 16, 'expr': None}}}]})
    edit_status = edited['rebuild']['doc_status']
    assert edit_status['features_executed'] == 1 and edit_status['features_reused'] == 2, edit_status
    assert abs(edited['volume'] - (40 * 24 * 12 + 1000 + 16 * 8 * 8)) < 1e-6
    report['tail_edit_status'] = edit_status
    activity, report['first_python_worker_rpc_ms'] = timed('worker_activity')
    report['python_worker_activity'] = activity
    assert activity.get('ok') and activity.get('complete') and activity['active'] == 0, activity
    info, report['first_agent_worker_rpc_ms'] = timed('worker_control_info')
    assert info.get('transport') == 'named_pipe', 'Native worker did not expose its real private pipe'
    report['agent_control_transport'] = info['transport']
    info.clear()  # Never retain control credentials in evidence or logs.
    latencies = []
    for _ in range(100):
        _result, duration = timed('ping')
        latencies.append(duration)
    report['ping_round_trip_ms'] = {'count': len(latencies), 'median': statistics.median(latencies),
                                  'p95': sorted(latencies)[94], 'maximum': max(latencies)}
    call('doc_close', {'doc_id': doc_id})
    stop()
    report['cache_only_build_connect_ms'] = start()
    cold_open, report['cache_only_build_ms'] = timed('doc_open', {'path': cold_request})
    assert cold_open['warm'] is False and cold_open['cache_hit'] is False, cold_open
    writeback = cold_open['cache']['writeback']
    assert writeback['written'] is True, writeback
    report['cache_only_writeback'] = writeback
    cold_active, _duration = timed('doc_activate', {'doc_id': cold_open['doc_id']})
    cold_status = cold_active['rebuild']['doc_status']
    assert cold_status['features_executed'] == 3 and cold_status['features_reused'] == 0, cold_status
    assert abs(cold_active['volume'] - (40 * 24 * 12 + 1000 + 8 * 8 * 8)) < 1e-6
    report['cache_only_built_status'] = cold_status
    call('doc_close', {'doc_id': cold_open['doc_id']})
    stop()
    with zipfile.ZipFile(cold_path) as archive:
        for name, data in source_members.items():
            assert archive.read(name) == data, name
    report['cache_only_source_members_preserved'] = True
    report['cache_only_restart_connect_ms'] = start()
    restored, report['cache_only_reopen_ms'] = timed('doc_open', {'path': str(cold_path)})
    require_trusted_checkpoint(restored)
    report['cache_only_reopened_cache'] = restored['cache']
    report['cache_only_reopened_trust'] = restored['cache_trust']
    restored_active, _duration = timed('doc_activate', {'doc_id': restored['doc_id']})
    restored_status = restored_active['rebuild']['doc_status']
    assert restored_status['features_executed'] == 0 and restored_status['features_reused'] == 3, restored_status
    call('doc_close', {'doc_id': restored['doc_id']})
    stop()
    report['clean_shutdown'] = True
    (output / 'native-runtime-final.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
except BaseException as error:
    report['failure'] = {'type': type(error).__name__, 'message': str(error)}
    (output / 'native-runtime-failure.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    raise
finally:
    if client:
        client.close()
    if process and process.poll() is None:
        process.terminate()
        process.wait(timeout=15)
