$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& 'C:\cw\python\python.exe' 'C:\cw\native-console-probe.py'
if ($LASTEXITCODE -ne 0) { throw 'Native console-allocation probe failed' }
Copy-Item -LiteralPath 'C:\cw\mesa\opengl32.dll','C:\cw\mesa\libgallium_wgl.dll' -Destination 'C:\cw\gui-noengine\bin'
Copy-Item -LiteralPath 'C:\cw\glfw-capability.exe' -Destination 'C:\cw\gui-noengine\bin'
$env:GALLIUM_DRIVER = 'llvmpipe'
& 'C:\cw\gui-noengine\bin\glfw-capability.exe' | Tee-Object -FilePath 'C:\cw\evidence\glfw-software.json'
if ($LASTEXITCODE -ne 0) { throw 'Software OpenGL capability probe failed' }
& 'C:\cw\python\python.exe' 'C:\cw\native-gui-probe.py'
if ($LASTEXITCODE -ne 0) { throw 'Native software desktop diagnostic failed' }
