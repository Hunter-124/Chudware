$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
$code = @'
import json, os, subprocess, time
from pathlib import Path
report = {'scope': 'Native subprocess console-allocation timing under WinRM; concurrent build load, not a quiet product benchmark', 'cases': []}
for name, flags in [('default', 0), ('no_window', subprocess.CREATE_NO_WINDOW), ('detached', subprocess.DETACHED_PROCESS)]:
    began = time.perf_counter()
    result = subprocess.run([os.environ['ComSpec'], '/d', '/c', 'exit 0'], creationflags=flags, capture_output=True, timeout=30)
    report['cases'].append({'mode': name, 'elapsed_ms': (time.perf_counter() - began) * 1000, 'exit_code': result.returncode})
    assert result.returncode == 0, report
Path(r'C:\cw\evidence\native-startup-console.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
'@
[IO.File]::WriteAllText('C:\cw\native-startup-probe.py', $code, (New-Object Text.UTF8Encoding($false)))
& 'C:\cw\python\python.exe' 'C:\cw\native-startup-probe.py'
if ($LASTEXITCODE -ne 0) { throw 'Native startup allocation probe failed' }
