$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
& $env:ComSpec /d /s /c 'C:\cw\run.cmd cmake --build --preset windows-occt --target test_sim_cache test_firmware test_hostd_worker_bridge_win chudware --parallel 3 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\core-targeted-build.log'
if ($LASTEXITCODE -ne 0) { throw 'Native targeted build failed' }
& $env:ComSpec /d /s /c 'C:\cw\run.cmd ctest --test-dir build/windows-occt/core --output-on-failure --no-tests=error -R "^(sim_cache|firmware|hostd_worker_bridge_windows)$" --output-junit C:/cw/evidence/core-targeted-ctest.xml 2>&1' | Tee-Object -FilePath 'C:\cw\evidence\core-targeted-ctest.log'
if ($LASTEXITCODE -ne 0) { throw 'Native targeted CTest failed' }
& C:\cw\run.cmd python -X utf8 C:\cw\native-runtime-smoke.py
if ($LASTEXITCODE -ne 0) { throw 'Native daemon/cache/worker smoke failed' }
