$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding
for ($pair = 1; $pair -le 3; $pair++) {
    $order = if ($pair % 2 -eq 0) { @('after', 'before') } else { @('before', 'after') }
    foreach ($phase in $order) {
        $arguments = @('-X', 'utf8', 'C:\cw\control-benchmark.py', '--output', ('C:\cw\evidence\control-paired-' + $phase + '-' + $pair + '.json'))
        if ($phase -eq 'before') { $arguments += '--before' }
        & C:\cw\run.cmd python @arguments
        if ($LASTEXITCODE -ne 0) { throw ('Matched control benchmark failed: ' + $phase) }
        $result = & C:\cw\run.cmd ('C:\cw\evidence\ipc-performance-' + $phase + '.exe')
        $status = $LASTEXITCODE
        $text = $result -join "`n"
        [IO.File]::WriteAllText(('C:\cw\evidence\ipc-paired-' + $phase + '-' + $pair + '.json'), $text, [Text.UTF8Encoding]::new($false))
        $decoded = $text | ConvertFrom-Json
        $result
        if ($decoded.responses_correct -ne $true -or ($phase -eq 'after' -and ($status -ne 0 -or $decoded.shutdown_woke -ne $true)) -or ($phase -eq 'before' -and $status -notin @(0,1))) {
            throw ('Matched transport benchmark failed: ' + $phase)
        }
    }
}
