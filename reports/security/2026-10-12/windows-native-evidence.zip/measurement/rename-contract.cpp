#define NOMINMAX
#include <windows.h>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <nlohmann/json.hpp>
namespace fs = std::filesystem;
std::string utf8(const std::wstring& value) {
    const int size = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(), static_cast<int>(value.size()), nullptr, 0, nullptr, nullptr);
    std::string result(size, '\0');
    if (size) WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, value.data(), static_cast<int>(value.size()), result.data(), size, nullptr, nullptr);
    return result;
}
int main() {
    const auto root = fs::path(L"C:\\cw\\evidence") / (L"rename-contract-" + std::to_wstring(GetCurrentProcessId()));
    fs::create_directory(root);
    nlohmann::json results = nlohmann::json::array();
    for (int index = 0; index < 3; ++index) {
        const auto source = root / (L"stage-" + std::to_wstring(index));
        const auto target = root / (L"intended-" + std::to_wstring(index) + L".step+");
        const HANDLE file = CreateFileW(source.c_str(), GENERIC_WRITE | DELETE | FILE_READ_ATTRIBUTES,
            FILE_SHARE_READ, nullptr, CREATE_NEW, FILE_ATTRIBUTE_TEMPORARY, nullptr);
        if (file == INVALID_HANDLE_VALUE) return 2;
        const auto destination = target.native();
        const auto bytes = destination.size() * sizeof(wchar_t);
        const auto declared = offsetof(FILE_RENAME_INFO, FileName) + bytes + (index == 2 ? sizeof(wchar_t) : 0);
        std::vector<unsigned char> storage(declared + 64, 0);
        auto* rename = reinterpret_cast<FILE_RENAME_INFO*>(storage.data());
        rename->ReplaceIfExists = TRUE;
        rename->FileNameLength = static_cast<DWORD>(bytes);
        std::memcpy(rename->FileName, destination.data(), bytes);
        const std::wstring poison = index == 0 ? L"-outside-length" : L"?";
        std::memcpy(storage.data() + declared, poison.c_str(), (poison.size() + 1) * sizeof(wchar_t));
        const bool success = SetFileInformationByHandle(file, FileRenameInfo, rename, static_cast<DWORD>(declared)) != FALSE;
        const DWORD error = success ? 0 : GetLastError();
        wchar_t final_path[4096]{};
        const DWORD length = GetFinalPathNameByHandleW(file, final_path, 4096, FILE_NAME_NORMALIZED);
        results.push_back({{"case", index == 0 ? "unterminated_suffix" : index == 1 ? "unterminated_invalid_suffix" : "terminated"},
            {"success", success}, {"winerror", error}, {"intended_exists", fs::is_regular_file(target)},
            {"actual_path", utf8(std::wstring(final_path, length))}});
        CloseHandle(file);
    }
    std::cout << results.dump(2, ' ', true) << '\n';
    fs::remove_all(root);
}
