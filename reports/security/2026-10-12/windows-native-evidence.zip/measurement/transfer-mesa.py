"""Stream verified diagnostic DLLs into the owned guest; never install system-wide."""
import base64
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import winrm

root = Path(__file__).resolve().parent
namespace = {'u': 'urn:schemas-microsoft-com:unattend'}
account = ET.parse(root / 'seed/autounattend.xml').find('.//u:LocalAccount', namespace)
protocol = winrm.Protocol(endpoint='http://127.0.0.1:44335/wsman', transport='ntlm',
    username=account.find('u:Name', namespace).text,
    password=account.find('u:Password/u:Value', namespace).text,
    read_timeout_sec=7200, operation_timeout_sec=60)
expected = {
    'opengl32.dll': '75b295fc80df0eaa8f1264c28663f6932c8b72d36513eb092556608858b7f5e0',
    'libgallium_wgl.dll': '53e49adf87590d5b0cab8553b1e98084812040cc1fca8c487695b17b7af3702e',
}
report = {'scope': 'Diagnostic-only per-application llvmpipe; not product or GPU qualification',
          'release': 'https://github.com/pal1000/mesa-dist-win/releases/tag/26.2.4',
          'archive_sha256': '351fc8c8b695878ffb3eaa044b3ead08672a48b1a045e3c3e3975811df0f6695',
          'files': []}
for name, digest in expected.items():
    source = root / 'mesa-payload' / name
    assert hashlib.file_digest(source.open('rb'), 'sha256').hexdigest() == digest
    size = source.stat().st_size
    code = f'''import hashlib,json,msvcrt,os,sys
from pathlib import Path
msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
target=Path(r'C:\\cw\\mesa') / {name!r}
target.parent.mkdir(exist_ok=True)
remaining={size}
digest=hashlib.sha256()
with target.open('xb') as output:
    while remaining:
        chunk=sys.stdin.buffer.read(min(65536, remaining))
        if not chunk: raise RuntimeError('Truncated diagnostic transfer')
        output.write(chunk)
        digest.update(chunk)
        remaining-=len(chunk)
assert digest.hexdigest()=={digest!r}, 'Diagnostic transfer digest mismatch'
print(json.dumps({{'name':target.name,'bytes':target.stat().st_size,'sha256':digest.hexdigest()}}))
'''
    encoded = base64.b64encode(code.encode()).decode('ascii')
    shell = protocol.open_shell()
    command = None
    try:
        command = protocol.run_command(shell, r'C:\cw\python\python.exe',
            ['-c', f'"exec(__import__(\'base64\').b64decode(\'{encoded}\'))"'],
            console_mode_stdin=False, skip_cmd_shell=True)
        with source.open('rb') as stream:
            while chunk := stream.read(65536):
                protocol.send_command_input(shell, command, chunk)
        protocol.send_command_input(shell, command, b'', end=True)
        stdout, stderr, status = protocol.get_command_output(shell, command)
        if status:
            raise RuntimeError(stderr.decode(errors='replace') or f'Transfer exit {status}')
        item = json.loads(stdout)
        report['files'].append(item)
        print(json.dumps(item), flush=True)
    finally:
        if command is not None:
            protocol.cleanup_command(shell, command)
        protocol.close_shell(shell)
(root / 'results/diagnostic-mesa.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
